
/**
 * Write a description of class myWindow here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
public class myWindow
  
{
    public static void main(String [] args){
        JFrame window = new JFrame();
        window.setTitle("My Window");
        window.setVisible(true);
        window.setBounds(0,0,800,300);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
 
    }
}
