import java.util.Scanner;
public class lowup
{
   public static void main(String[] args){
        String mystring = "Hello";
        char result;
        System.out.print(mystring.replace("o", "p"));
        //System.out.print(mystring.indexOf("H"));
        //System.out.print(mystring.startsWith("H"));
        
        //String name;
        //Scanner input = new Scanner(System.in);
        //System.out.print("Enter your name: ");
        //name = input.nextLine();
        //System.out.print("Name: " + name);
        
        
               
    }
}