import java.util.Scanner;
public class Compare1{
    public static void main(String[] args){
        String aName = "Bella";
        String anotherName;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter your name: ");
        anotherName = input.nextLine();
        if(aName.equalsIgnoreCase(anotherName))
        //if(aName.equals(anotherName))
        System.out.println(aName + " is equal to " + anotherName);
        else
        System.out.println(aName + " does not equal " + anotherName);
    }
}