
/**
 * Write a description of class Dog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Dog
{
    String breed = "aspin";
    String tagnumber = "oct27";
    String color = "black";

    public static void main (String[] args){
        Dog myDog = new Dog();
        myDog.printinfo();
        
        
    }
    public void printinfo(){
        System.out.println("Breed: " + breed);
        System.out.println("Tagnumber: " + tagnumber);
        System.out.println("Color: " + color);

    }
    
    public void Dog(String breed, String tagnumber, String color){
        System.out.println("Breed: " + breed);
        System.out.println("Tagnumber: " + tagnumber);
        System.out.println("Color: " + color);
        
}
}