import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class GUI_Form extends JFrame{
    JButton okButton = new JButton();
    JButton exitButton = new JButton();
    
    JLabel breedlabel = new JLabel();
    JLabel tagnolabel = new JLabel();
    JLabel colorlabel = new JLabel();
    
    JTextField breedtextfield = new JTextField();
    JTextField tagnotextfield = new JTextField();
    JTextField colortextfield = new JTextField();
    
    public GUI_Form(){
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
    
        okButton.setText("OK");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        getContentPane().add(okButton, gridConstraints);
        
        okButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                okButtonActionPerformer(e);
            };
        });
        
        exitButton.setText("EXIT");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        getContentPane().add(exitButton, gridConstraints);
        
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                exitButtonActionPerformer(e);
            };
        });
        
        breedlabel.setText("Breed: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(breedlabel, gridConstraints);
        
        tagnolabel.setText("Tag number: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        getContentPane().add(tagnolabel, gridConstraints);
        
        colorlabel.setText("Color: ");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(colorlabel, gridConstraints);
        
        breedtextfield.setText("");
        breedtextfield.setColumns(10);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        getContentPane().add(breedtextfield, gridConstraints);
        
        tagnotextfield.setText("");
        tagnotextfield.setColumns(10);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        getContentPane().add(tagnotextfield, gridConstraints);
        
        colortextfield.setText("");
        colortextfield.setColumns(10);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        getContentPane().add(colortextfield, gridConstraints);
        
        addWindowListener (new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                exitForm(e);
            }
        });
        pack();
    }
    
    private void exitForm(WindowEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Exiting...");
    }
    
    private void okButtonActionPerformer(ActionEvent e){
        //JFrame f;
        //f = new JFrame();
        JOptionPane.showMessageDialog(null, "Breed: " + breedtextfield.getText() + " " + "\nTag number: " + tagnotextfield.getText() + " " +  "\nColor: " + colortextfield.getText(), "Hello", JOptionPane.PLAIN_MESSAGE);
    }
    
    private void exitButtonActionPerformer(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thanks!");
        System.exit(0);
    }
    
    public static void main (String[] args){
        new GUI_Form().show();
    }
    
    }
           
